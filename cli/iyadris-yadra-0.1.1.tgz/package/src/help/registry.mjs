import { readCliVersion } from "../config/manifest.mjs";

export function globalHelp() {
  const v = readCliVersion();
  return `Yadra CLI v${v} — Ingénierie formelle KSL

Usage:
  yadra <commande> [options]

Commandes:
  version      Affiche la version CLI (yadra/manifest.mf) et le projet actif
  help         Aide globale ou yadra <commande> -h
  configure    Profils LLM et credentials (~/.config/yadra/)
  project      Enregistre et active les projets (KSL + code)
  formalize    Si KSL absent : infos A/B ; si présent : validate + seal
  validate     Validation KSL L0–L3
  seal         Scellement T1 (.yadra/sealed/)
  doctor       Diagnostic environnement

Exécutez "yadra <commande> -h" pour le détail.`;
}

export function commandHelp(name) {
  const map = {
    version: `Usage: yadra version [--format human|json]

Affiche la version lue depuis yadra/manifest.mf, KSL_HOME, grammaire et projet actif.`,
    help: `Usage: yadra help [commande]
       yadra -h`,
    configure: `Usage:
  yadra configure list
  yadra configure set --profile <nom> [--provider <id>] [--model <id>] [--base-url <url>] [--timeout <ms>]
  yadra configure credentials --profile <nom> [--token <val>] [--username <u>] [--password <p>]
  yadra configure get <clé> [--profile <nom>]

Stocke configure et credentials sous ~/.config/yadra/.`,
    project: `yadra project — registre multi-projets (v0.1.1+)

Un projet = KSL_PROJECT_HOME (specs .ksl) + PROJECT_HOME (code généré).
Chemins persistés en absolu dans ~/.config/yadra/projects.json (champ "current").

Sous-commandes:
  list              Tableau name / KSL / PROJECT / * = courant
  add <name>        Enregistre un projet (--ksl-project-home requis)
  update <name>     Met à jour chemins et/ou LLM (profil seul : pas de re-scan KSL)
  set-profile [<name>] --profile <p> [--model <id>]
                    Profil yadra configure + modèle pour ce projet (<name> = courant si omis)
  use <name>        Active un projet (formalize / validate / seal suivent ce couple)
  show [name]       Détail du projet courant ou nommé
  export            export shell: YADRA_PROJECT, KSL_PROJECT_HOME, PROJECT_HOME, …
  remove <name>     Retire du registre (interdit si projet courant)
  clear             current = null (entrées conservées)

Options (add / update):
  --ksl-project-home <path>   Root KSL (*.project.ksl kind = root) → absolu
  --project-home <path>       Dépôt applicatif → absolu
  --yadra-project-home <path> Distribution Yadra (souvent auto via paquet CLI)
  --profile <name>            Profil dans ~/.config/yadra/configure
  --model <id>                Modèle par défaut pour formalize (SKILLS A/B)
  --no-current                (add) n'active pas après création

Surcharge ponctuelle (formalize, validate, seal):
  --project <name>            Projet enregistré sans changer "current"
  --ksl-project-home / --project-home / --profile / --model

Variables: YADRA_PROJECT=<name>  |  KSL_PROJECT_HOME / PROJECT_HOME (CI)

Exemple:
  yadra project add tontine --ksl-project-home ~/tontine-ksl --project-home ~/tontine-app
  yadra project add order --ksl-project-home ~/platform-ksl --project-home ~/order-app --no-current
  yadra project use order
  yadra project set-profile order --profile prod
  eval "$(yadra project export)"`,
    formalize: `Usage: yadra formalize <dossier-documents> [options]

Prérequis : yadra project use <name> (ou --project / --ksl-project-home)
Entrée obligatoire : <dossier-documents>/feature.yadra.md (output_paths.spec requis).

Si un fichier listé dans output_paths (root, module, spec) manque sous KSL_PROJECT_HOME :
  crée KSL_PROJECT_HOME/.yadra/tmp/<run-id>/, affiche chemins plans/skills, code sortie 1.
Si tous existent :
  yadra validate sur chaque fichier (L0+L2+L3, +L1 si --syntax), puis yadra seal (défaut).

Le binaire n'exécute pas de LLM ni ne génère de .ksl.

Options:
  --seal / --no-seal   Scellement (défaut : --seal)
  --syntax             L1 lors de validate/seal
  --include <paths>    Fichiers .ksl extra pour seal
  --project <name>     Projet enregistré (one-shot)
  --ksl-project-home, --project-home, --yadra-project-home
  --model, --profile   Surcharge env (affichées si branche A/B)`,
    validate: `Usage: yadra validate [PATH] [--syntax] [--layout] [--semantic] [--format human|json] [--project <name>] …`,
    seal: `Usage: yadra seal [SPEC.spec.ksl] [--syntax] [--include path,...] [--project <name>] …`,
    doctor: `Usage: yadra doctor

Vérifie Node, manifest, KSL_HOME, projet actif.`,
  };
  return map[name] ?? `No help for: ${name}\n\n${globalHelp()}`;
}
