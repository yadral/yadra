#!/usr/bin/env node
import { applyInstallEnv } from "./runtime/distribution.mjs";
applyInstallEnv();

import { resolve } from "node:path";
import { cmdConfigure } from "./commands/configure.mjs";
import { cmdContext } from "./commands/context.mjs";
import { cmdDoctor } from "./commands/doctor.mjs";
import { cmdFormalize } from "./commands/formalize.mjs";
import { cmdHelp } from "./commands/help.mjs";
import { cmdSeal } from "./commands/seal.mjs";
import { cmdValidate } from "./commands/validate.mjs";
import { cmdVersion } from "./commands/version.mjs";
import { commandHelp, globalHelp } from "./help/registry.mjs";
import { ENV_KSL, ENV_MODEL, ENV_PROJECT, ENV_YADRA } from "./config/load-context.mjs";
import { parseArgs } from "./util/parse-args.mjs";

const COMMON_CONTEXT_OVERRIDES = [
  "--ksl-project-home",
  "--project-home",
  "--yadra-project-home",
];

function allowedFlags(cmd, sub) {
  const byCommand = {
    version: ["--format"],
    doctor: [],
    formalize: [
      "--seal",
      "--no-seal",
      "--syntax",
      "--include",
      "--model",
      "--profile",
      ...COMMON_CONTEXT_OVERRIDES,
    ],
  validate: ["--syntax", "--layout", "--semantic", "--format", ...COMMON_CONTEXT_OVERRIDES],
  seal: ["--syntax", "--include", ...COMMON_CONTEXT_OVERRIDES],
  };
  if (cmd === "configure") {
    if (sub === "set") {
      return ["--profile", "--provider", "--model", "--base-url", "--timeout"];
    }
    if (sub === "credentials") {
      return ["--profile", "--token", "--username", "--password"];
    }
    if (sub === "get") return ["--profile"];
    return [];
  }
  if (cmd === "context") {
    if (sub === "set") {
      return [
        "--ksl-project-home",
        "--project-home",
        "--yadra-project-home",
        "--model",
        "--profile",
      ];
    }
    return [];
  }
  return byCommand[cmd] ?? [];
}

function unsupportedFlag(cmd, sub, provided) {
  const allowed = new Set(allowedFlags(cmd, sub));
  return [...provided].find(
    (flag) => flag !== "--help" && flag !== "-h" && !allowed.has(flag),
  );
}

function applyTransientOverrides(flags, cwd) {
  if (flags.kslProjectHome) {
    process.env[ENV_KSL] = resolve(cwd, flags.kslProjectHome);
  }
  if (flags.projectHome) process.env[ENV_PROJECT] = resolve(cwd, flags.projectHome);
  if (flags.yadraProjectHome) {
    process.env[ENV_YADRA] = resolve(cwd, flags.yadraProjectHome);
  }
  if (flags.model) process.env[ENV_MODEL] = flags.model;
  if (flags.profile) process.env.YADRA_PROFILE = flags.profile;
}

async function main() {
  const argv = process.argv.slice(2);
  const cwd = process.cwd();

  if (argv.length === 0 || argv[0] === "--help" || argv[0] === "-h") {
    console.log(globalHelp());
    process.exit(argv.length === 0 ? 2 : 0);
  }

  const [cmd, ...rest] = argv;

  if (cmd === "help") {
    const { flags, positional, error } = parseArgs(rest);
    if (error) {
      console.error(error);
      process.exit(2);
    }
    process.exit(cmdHelp(positional[0], flags));
  }

  const { flags, positional, error, provided } = parseArgs(rest);
  if (error) {
    console.error(error);
    process.exit(2);
  }

  if (flags.help) {
    console.log(commandHelp(cmd));
    process.exit(0);
  }
  if (provided.has("--seal") && provided.has("--no-seal")) {
    console.error("--seal and --no-seal cannot be used together.");
    process.exit(2);
  }

  const knownCommands = new Set([
    "version",
    "doctor",
    "configure",
    "context",
    "formalize",
    "validate",
    "seal",
  ]);
  const sub = ["configure", "context"].includes(cmd) ? positional[0] : null;
  if (knownCommands.has(cmd)) {
    const unsupported = unsupportedFlag(cmd, sub, provided);
    if (unsupported) {
      console.error(
        `Unsupported flag for ${cmd}${sub ? ` ${sub}` : ""}: ${unsupported}`,
      );
      process.exit(2);
    }
  }

  applyTransientOverrides(flags, cwd);

  let code = 2;
  switch (cmd) {
    case "version":
      if (positional.length > 0) {
        console.error(`Unexpected argument: ${positional[0]}`);
        code = 2;
      } else {
        code = cmdVersion(flags, cwd);
      }
      break;
    case "doctor":
      if (positional.length > 0) {
        console.error(`Unexpected argument: ${positional[0]}`);
        code = 2;
      } else {
        code = cmdDoctor(flags, cwd);
      }
      break;
    case "configure": {
      const [sub, ...args] = positional;
      code = cmdConfigure(sub, args, flags);
      break;
    }
    case "context": {
      const [sub, ...args] = positional;
      code = cmdContext(sub, args, flags, cwd);
      break;
    }
    case "formalize":
      code = cmdFormalize(flags, positional, cwd);
      break;
    case "validate":
      code = cmdValidate(flags, positional, cwd);
      break;
    case "seal":
      code = cmdSeal(flags, positional, cwd);
      break;
    default:
      console.error(`Unknown command: ${cmd}\n`);
      console.log(globalHelp());
      code = 2;
  }

  process.exit(code ?? 0);
}

main().catch((e) => {
  console.error(e?.message ?? e);
  process.exit(2);
});
