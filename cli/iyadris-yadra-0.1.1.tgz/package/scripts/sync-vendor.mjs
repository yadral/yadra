#!/usr/bin/env node
/**
 * Copie la distribution minimale dans vendor/iyadris-yadra (tarball + dev).
 */
import { cpSync, existsSync, mkdirSync, rmSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const CLI_ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const REPO_ROOT = resolve(CLI_ROOT, "../..");
const VENDOR = join(CLI_ROOT, "vendor/iyadris-yadra");

const PATHS = [
  { from: join(REPO_ROOT, "yadra/manifest.mf"), to: "yadra/manifest.mf" },
  { from: join(REPO_ROOT, "yadra/skills"), to: "yadra/skills" },
  { from: join(REPO_ROOT, "ksl/grammar"), to: "ksl/grammar" },
  { from: join(REPO_ROOT, "ksl/tools/yadra/lib"), to: "ksl/tools/yadra/lib" },
  {
    from: join(REPO_ROOT, "prompts/plan/yadra/v1"),
    to: "prompts/plan/yadra/v1",
  },
];

function main() {
  const strict = process.env.YADRA_VENDOR_STRICT === "1";
  if (!existsSync(join(REPO_ROOT, "yadra/manifest.mf"))) {
    const msg = "sync-vendor: not in iyadris-yadra monorepo (yadra/manifest.mf missing)";
    if (strict) {
      throw new Error(msg);
    }
    console.warn(`${msg}; skip`);
    return;
  }
  for (const { from } of PATHS) {
    if (!existsSync(from)) {
      throw new Error(`sync-vendor: missing ${from}`);
    }
  }
  rmSync(VENDOR, { recursive: true, force: true });
  mkdirSync(VENDOR, { recursive: true });
  for (const { from, to } of PATHS) {
    const dest = join(VENDOR, to);
    mkdirSync(dirname(dest), { recursive: true });
    cpSync(from, dest, { recursive: true });
  }
  console.log(`vendor: copied → ${VENDOR}`);
}

main();
