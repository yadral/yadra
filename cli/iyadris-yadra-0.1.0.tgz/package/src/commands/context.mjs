import { resolveKslHome } from "../runtime/ksl-lib.mjs";
import {
  contextClear,
  contextExportLines,
  contextSetFromOptions,
  findRootProjectInDir,
  requireKslProjectHome,
  resolveWorkspace,
} from "../config/load-context.mjs";
import { globalContextPath } from "../config/paths.mjs";

export function cmdContext(sub, positional, flags, cwd) {
  if (sub === "set") {
    if (positional.length > 1) {
      console.error(`Unexpected argument: ${positional[1]}`);
      return 2;
    }
    const ksl = flags.kslProjectHome ?? positional[0];
    try {
      const record = contextSetFromOptions({
        kslProjectHome: ksl,
        projectHome: flags.projectHome,
        yadraProjectHome: flags.yadraProjectHome,
        model: flags.model,
        profile: flags.profile,
      });
      console.log(`Context set: KSL_PROJECT_HOME=${record.kslProjectHome}`);
      if (record.projectHome) console.log(`  PROJECT_HOME=${record.projectHome}`);
      if (record.yadraProjectHome) {
        console.log(`  YADRA_PROJECT_HOME=${record.yadraProjectHome}`);
      }
      console.log(`  root: ${record.rootProjectFile} (${record.projectId})`);
      return 0;
    } catch (e) {
      console.error(e.message);
      return 1;
    }
  }

  if (sub === "show") {
    if (positional.length > 0) {
      console.error(`Unexpected argument: ${positional[0]}`);
      return 2;
    }
    const ws = resolveWorkspace(cwd);
    console.log("Active context:");
    if (!ws) {
      console.log("  (not set)");
      console.log(`  global: ${globalContextPath()}`);
      console.log(`  KSL_HOME: ${resolveKslHome()}`);
      return 0;
    }
    console.log(`  YADRA_PROJECT_HOME: ${ws.yadraProjectHome ?? "(auto)"}`);
    console.log(`  KSL_PROJECT_HOME:   ${ws.kslProjectHome}`);
    console.log(`  PROJECT_HOME:       ${ws.projectHome ?? "(not set)"}`);
    const meta = findRootProjectInDir(ws.kslProjectHome);
    if (meta) {
      console.log(`  root file: ${meta.rootProjectFile}`);
      console.log(`  project id: ${meta.projectId}`);
    }
    console.log(`  LLM profile: ${ws.llm?.profile ?? "default"}`);
    console.log(`  LLM model:   ${ws.llm?.model ?? "(from configure)"}`);
    console.log(`  global config: ${globalContextPath()}`);
    return 0;
  }

  if (sub === "export") {
    if (positional.length > 0) {
      console.error(`Unexpected argument: ${positional[0]}`);
      return 2;
    }
    try {
      const ws = requireKslProjectHome(cwd);
      for (const line of contextExportLines(ws)) console.log(line);
      return 0;
    } catch (e) {
      console.error(e.message);
      return 1;
    }
  }

  if (sub === "clear") {
    if (positional.length > 0) {
      console.error(`Unexpected argument: ${positional[0]}`);
      return 2;
    }
    contextClear();
    console.log("Cleared global Yadra context.");
    return 0;
  }

  console.error("Usage: yadra context set|show|export|clear");
  return 2;
}
