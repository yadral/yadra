# Yadra CLI

Binaire **`yadra`** (Node ≥ 18). Distribution embarquée dans `vendor/` (tarball) ou lien monorepo (`npm install` / `prepare`).

## Install dev — option 2 (tarball)

### Qui publie le `.tgz`

Depuis la racine du monorepo :

```bash
cd yadra/cli
npm run release:pack
# → iyadris-yadra-<version>.tgz (nom npm = @iyadris/yadra)
```

Puis joindre le `.tgz` à une **GitHub Release** du repo [iyadris/yadra](https://github.com/iyadris/yadra) (ou interface web Releases). En CLI :

Prérequis : [GitHub CLI](https://cli.github.com/) — macOS `brew install gh` ; Debian/Ubuntu `sudo apt install gh` ; Fedora `sudo dnf install gh` ; puis `gh auth login`. Détail : doc [Package process](/docs/package-process/).

```bash
git push origin main
npm run release:github -- yadra-cli-v0.1.2
```

(Sans `--`, tag par défaut = `yadra-cli-v` + version de `package.json`.)

Contenu du paquet : CLI + `vendor/iyadris-yadra/` (grammaire, lib KSL, `yadra/manifest.mf`, skills T1/T2, plans `yadra/v1`).

### Qui installe

Node 18+ :

```bash
npm install -g ./iyadris-yadra-0.1.2.tgz
yadra version
```

`YADRA_PROJECT_HOME` et `KSL_HOME` sont définis au démarrage depuis la distribution installée — **pas** de `--yadra-project-home` en usage normal.

Projet métier :

```bash
yadra project add myapp --ksl-project-home /chemin/vers/monorepo-ksl --project-home /chemin/vers/app
yadra project use myapp
```

## Test release (local)

```bash
cd yadra/cli
npm run release:pack
npm run release:smoke
```

## Développement dans le monorepo

```bash
cd yadra/cli
npm install    # prepare → copie vendor/iyadris-yadra
npm test
npm link       # optionnel : yadra sur le PATH
```

Doc utilisateur : [`../documentation/`](../documentation/) — processus release : page **Package process**.
