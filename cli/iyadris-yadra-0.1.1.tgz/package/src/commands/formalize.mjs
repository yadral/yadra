import { existsSync, mkdirSync, statSync } from "node:fs";
import { isAbsolute, join, relative, resolve, sep } from "node:path";
import { runSeal, runValidate } from "../runtime/ksl-lib.mjs";
import { getProfileConfig } from "../config/load-configure.mjs";
import { requireKslProjectHome, syncKslToolEnv } from "../config/load-projects.mjs";
import { loadFeatureYadra } from "../util/feature-yadra.mjs";
import {
  printAbOrchestration,
  resolveFormalizeAssets,
} from "../util/formalize-contract.mjs";

function kslFilesFromFeature(kslRoot, feature) {
  const paths = [];
  for (const key of ["root", "module", "spec"]) {
    const outputPath = feature.outputPaths[key];
    if (!outputPath) continue;
    if (isAbsolute(outputPath)) {
      throw new Error(`output_paths.${key} must be relative: ${outputPath}`);
    }
    const absolute = resolve(kslRoot, outputPath);
    const fromRoot = relative(kslRoot, absolute);
    if (fromRoot === ".." || fromRoot.startsWith(`..${sep}`)) {
      throw new Error(
        `output_paths.${key} escapes KSL_PROJECT_HOME: ${outputPath}`,
      );
    }
    paths.push(absolute);
  }
  return paths;
}

function llmFromContext(ws) {
  const profile =
    process.env.YADRA_PROFILE ?? ws.llm?.profile ?? "default";
  const { configure } = getProfileConfig(profile);
  return {
    profile,
    provider: configure.provider ?? null,
    model:
      ws.llm?.model ??
      configure.model ??
      process.env.YADRA_MODEL ??
      null,
  };
}

function runPhaseC(flags, cwd, ws, feature, files) {
  const assets = resolveFormalizeAssets(ws.yadraProjectHome);
  console.log("T1 formalize — C · EXÉCUTER (validate / seal)");
  console.log(`  plan: ${assets.plans.executer}`);
  console.log(`  skill: ${assets.skills.executer}`);
  console.log("");

  const validateOpts = {
    syntax: flags.syntax,
    layout: true,
    semantic: true,
    format: "human",
  };

  for (const file of files) {
    console.log(`validate ${file}`);
    const r = runValidate(file, validateOpts);
    if (r.exitCode !== 0) return r.exitCode;
  }

  if (flags.noSeal || !flags.seal) {
    console.log("Validation OK (--no-seal: pas de scellement).");
    return 0;
  }

  const specRel = feature.outputPaths.spec;
  const specAbs = resolve(ws.kslProjectHome, specRel);
  const include = flags.include.map((p) => resolve(cwd, p));
  const missingInclude = include.filter((p) => !existsSync(p));
  if (missingInclude.length > 0) {
    for (const path of missingInclude) {
      console.error(`seal: include file not found: ${path}`);
    }
    return 2;
  }
  const invalidInclude = include.filter(
    (p) => !p.endsWith(".ksl") || !statSync(p).isFile(),
  );
  if (invalidInclude.length > 0) {
    for (const path of invalidInclude) {
      console.error(`seal: include is not a .ksl file: ${path}`);
    }
    return 2;
  }
  console.log(`seal ${specAbs}`);
  return runSeal(specAbs, {
    syntax: flags.syntax,
    layout: true,
    semantic: true,
    include,
  });
}

export function cmdFormalize(flags, positional, cwd, wsOptions = {}) {
  const docArg = positional[0];
  if (!docArg) {
    console.error("Usage: yadra formalize <dossier-documents> [options]");
    return 2;
  }
  if (positional.length > 1) {
    console.error(`Unexpected argument: ${positional[1]}`);
    return 2;
  }

  syncKslToolEnv(cwd, wsOptions);
  let ws;
  try {
    ws = requireKslProjectHome(cwd, wsOptions);
  } catch (e) {
    console.error(e.message);
    return 2;
  }
  const docDir = resolve(cwd, docArg);
  const featurePath = join(docDir, "feature.yadra.md");
  if (!existsSync(featurePath)) {
    console.error(`Missing ${featurePath}`);
    return 1;
  }

  let feature;
  try {
    feature = loadFeatureYadra(docDir);
  } catch (e) {
    console.error(e.message);
    return 1;
  }

  const specRel = feature.outputPaths.spec;
  if (!specRel) {
    console.error("feature.yadra.md: output_paths.spec est requis.");
    return 1;
  }

  let files;
  try {
    files = kslFilesFromFeature(ws.kslProjectHome, feature);
  } catch (e) {
    console.error(e.message);
    return 1;
  }
  const missing = files.filter((f) => !existsSync(f));

  if (missing.length > 0) {
    const runId =
      process.env.YADRA_FORMALIZE_RUN_ID ??
      `formalize-${new Date().toISOString().replace(/[:.]/g, "-")}`;
    const tmpDir = resolve(ws.kslProjectHome, ".yadra", "tmp", runId);
    try {
      mkdirSync(tmpDir, { recursive: true });
    } catch {
      // non-fatal
    }
    printAbOrchestration({
      docDir,
      kslProjectHome: ws.kslProjectHome,
      yadraProjectHome: ws.yadraProjectHome,
      llm: llmFromContext(ws),
      runId,
    });
    console.error("");
    console.error("Livrables KSL absents (terminer A · COMPRENDRE puis B · PRODUIRE) :");
    for (const f of missing) console.error(`  - ${f}`);
    console.error("");
    console.error(
      "Relancez la même commande une fois les fichiers écrits sous KSL_PROJECT_HOME.",
    );
    return 1;
  }

  return runPhaseC(flags, cwd, ws, feature, files);
}
