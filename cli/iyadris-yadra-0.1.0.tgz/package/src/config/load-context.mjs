import {
  existsSync,
  mkdirSync,
  readFileSync,
  rmSync,
  writeFileSync,
} from "node:fs";
import { dirname, join, resolve } from "node:path";
import {
  findRootProjectInDir,
  validateAndBuildContext,
} from "../runtime/ksl-lib.mjs";
import { assertProfileName } from "./load-configure.mjs";
import { defaultYadraProjectHome } from "./manifest.mjs";
import { globalContextPath, localContextPath } from "./paths.mjs";

export const ENV_KSL = "KSL_PROJECT_HOME";
export const ENV_PROJECT = "PROJECT_HOME";
export const ENV_YADRA = "YADRA_PROJECT_HOME";
export const ENV_MODEL = "YADRA_MODEL";
const ENV_KSL_TOOL_ROOT = "YADRA_PROJECT_ROOT";

function readJson(path) {
  if (!existsSync(path)) return null;
  try {
    return JSON.parse(readFileSync(path, "utf8"));
  } catch {
    return null;
  }
}

function normalizeRecord(raw) {
  if (!raw || typeof raw !== "object") return null;
  const ksl = raw.kslProjectHome ?? raw.projectRoot ?? null;
  if (!ksl) return null;
  return {
    version: raw.version ?? 1,
    kslProjectHome: resolve(ksl),
    projectHome: raw.projectHome ? resolve(raw.projectHome) : null,
    yadraProjectHome: raw.yadraProjectHome
      ? resolve(raw.yadraProjectHome)
      : defaultYadraProjectHome(),
    rootProjectFile: raw.rootProjectFile ?? null,
    projectId: raw.projectId ?? null,
    llm: raw.llm ?? {},
    setAt: raw.setAt ?? raw.updatedAt ?? null,
  };
}

export function loadLocalContextFromWalk(cwd) {
  let dir = resolve(cwd);
  for (let i = 0; i < 32; i++) {
    const path = join(dir, ".yadra", "context.json");
    const rec = normalizeRecord(readJson(path));
    if (rec) return rec;
    const parent = dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return null;
}

export function loadGlobalContext() {
  return normalizeRecord(readJson(globalContextPath()));
}

export function resolveWorkspace(cwd = process.cwd()) {
  const envKsl =
    process.env[ENV_KSL] ??
      process.env[ENV_KSL_TOOL_ROOT] ??
    process.env.YADRA_CONTEXT;
  const base = envKsl
    ? normalizeRecord({ kslProjectHome: envKsl })
    : loadLocalContextFromWalk(cwd) ?? loadGlobalContext();
  if (!base) return null;

  return {
    ...base,
    projectHome: process.env[ENV_PROJECT]
      ? resolve(process.env[ENV_PROJECT])
      : base.projectHome,
    yadraProjectHome: process.env[ENV_YADRA]
      ? resolve(process.env[ENV_YADRA])
      : base.yadraProjectHome,
    llm: {
      ...(base.llm ?? {}),
      ...(process.env.YADRA_PROFILE
        ? { profile: process.env.YADRA_PROFILE }
        : {}),
      ...(process.env[ENV_MODEL]
        ? { model: process.env[ENV_MODEL] }
        : {}),
    },
  };
}

export function requireKslProjectHome(cwd = process.cwd()) {
  const ws = resolveWorkspace(cwd);
  if (!ws?.kslProjectHome) {
    throw new Error(
      "No KSL project context. Run: yadra context set --ksl-project-home <path>",
    );
  }
  if (!existsSync(ws.kslProjectHome)) {
    throw new Error(`KSL_PROJECT_HOME does not exist: ${ws.kslProjectHome}`);
  }
  return ws;
}

/**
 * Aligne process.env pour la lib partagée ksl/tools/yadra (validate, seal, context).
 * Elle lit encore YADRA_PROJECT_ROOT (= KSL_PROJECT_HOME).
 */
export function syncKslToolEnv(cwd = process.cwd()) {
  const ws = resolveWorkspace(cwd);
  if (ws?.kslProjectHome) {
    process.env[ENV_KSL] = ws.kslProjectHome;
    process.env[ENV_KSL_TOOL_ROOT] = ws.kslProjectHome;
    process.env.YADRA_CONTEXT = ws.kslProjectHome;
  }
  if (ws?.projectHome) process.env[ENV_PROJECT] = ws.projectHome;
  if (ws?.yadraProjectHome) process.env[ENV_YADRA] = ws.yadraProjectHome;
  const model = ws?.llm?.model ?? process.env[ENV_MODEL];
  if (model) process.env[ENV_MODEL] = model;
}

export function saveContext(record) {
  const payload = {
    version: 1,
    kslProjectHome: record.kslProjectHome,
    projectHome: record.projectHome ?? undefined,
    yadraProjectHome: record.yadraProjectHome ?? undefined,
    rootProjectFile: record.rootProjectFile,
    projectId: record.projectId,
    llm: record.llm ?? {},
    updatedAt: new Date().toISOString(),
  };
  mkdirSync(dirname(globalContextPath()), { recursive: true });
  writeFileSync(globalContextPath(), `${JSON.stringify(payload, null, 2)}\n`);
  const local = localContextPath(record.kslProjectHome);
  mkdirSync(dirname(local), { recursive: true });
  writeFileSync(local, `${JSON.stringify(payload, null, 2)}\n`);
  process.env[ENV_KSL] = record.kslProjectHome;
  process.env[ENV_KSL_TOOL_ROOT] = record.kslProjectHome;
  process.env.YADRA_CONTEXT = record.kslProjectHome;
  if (record.projectHome) process.env[ENV_PROJECT] = record.projectHome;
  if (record.yadraProjectHome) process.env[ENV_YADRA] = record.yadraProjectHome;
  if (record.llm?.model) process.env[ENV_MODEL] = record.llm.model;
  if (record.llm?.profile) process.env.YADRA_PROFILE = record.llm.profile;
}

export function contextSetFromOptions(options) {
  const kslPath = options.kslProjectHome;
  if (!kslPath) {
    throw new Error("--ksl-project-home <path> is required (or positional path).");
  }
  if (options.profile) assertProfileName(options.profile);
  const rootMeta = validateAndBuildContext(kslPath);
  const previous = loadGlobalContext();
  const record = {
    kslProjectHome: rootMeta.projectRoot,
    projectHome: options.projectHome
      ? resolve(options.projectHome)
      : previous?.projectHome ?? null,
    yadraProjectHome: options.yadraProjectHome
      ? resolve(options.yadraProjectHome)
      : previous?.yadraProjectHome ?? defaultYadraProjectHome(),
    rootProjectFile: rootMeta.rootProjectFile,
    projectId: rootMeta.projectId,
    llm: {
      profile: options.profile ?? previous?.llm?.profile ?? "default",
      model: options.model ?? previous?.llm?.model ?? undefined,
    },
  };
  saveContext(record);
  return record;
}

export function contextClear() {
  const p = globalContextPath();
  if (existsSync(p)) rmSync(p);
  delete process.env[ENV_KSL];
  delete process.env[ENV_KSL_TOOL_ROOT];
  delete process.env.YADRA_CONTEXT;
  delete process.env[ENV_PROJECT];
  delete process.env[ENV_YADRA];
  delete process.env[ENV_MODEL];
  delete process.env.YADRA_PROFILE;
}

export function contextExportLines(ws) {
  const lines = [];
  if (ws.yadraProjectHome) {
    lines.push(`export ${ENV_YADRA}='${ws.yadraProjectHome.replace(/'/g, "'\\''")}'`);
  }
  lines.push(`export ${ENV_KSL}='${ws.kslProjectHome.replace(/'/g, "'\\''")}'`);
  if (ws.projectHome) {
    lines.push(`export ${ENV_PROJECT}='${ws.projectHome.replace(/'/g, "'\\''")}'`);
  }
  if (ws.llm?.model) {
    lines.push(`export ${ENV_MODEL}='${String(ws.llm.model).replace(/'/g, "'\\''")}'`);
  }
  if (ws.llm?.profile) {
    lines.push(`export YADRA_PROFILE='${String(ws.llm.profile).replace(/'/g, "'\\''")}'`);
  }
  return lines;
}

export { findRootProjectInDir };
