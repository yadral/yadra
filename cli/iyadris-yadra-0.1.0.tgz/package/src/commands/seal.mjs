import { existsSync, statSync } from "node:fs";
import { resolve } from "node:path";
import { resolveSpecPath, runSeal } from "../runtime/ksl-lib.mjs";
import { syncKslToolEnv } from "../config/load-context.mjs";

export function cmdSeal(flags, positional, cwd) {
  if (positional.length > 1) {
    console.error(`Unexpected argument: ${positional[1]}`);
    return 2;
  }
  syncKslToolEnv(cwd);
  let spec;
  try {
    spec = resolveSpecPath(positional[0] ?? ".", cwd);
  } catch (e) {
    console.error(e.message);
    return 2;
  }
  const include = flags.include.map((p) => resolve(cwd, p));
  const missing = include.filter((p) => !existsSync(p));
  if (missing.length > 0) {
    for (const path of missing) console.error(`seal: include file not found: ${path}`);
    return 2;
  }
  const invalid = include.filter(
    (p) => !p.endsWith(".ksl") || !statSync(p).isFile(),
  );
  if (invalid.length > 0) {
    for (const path of invalid) console.error(`seal: include is not a .ksl file: ${path}`);
    return 2;
  }
  return runSeal(spec, {
    syntax: flags.syntax,
    layout: true,
    semantic: true,
    include,
  });
}
