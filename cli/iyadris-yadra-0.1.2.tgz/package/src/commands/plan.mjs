import { resolveSpecPath, runPlan } from "../runtime/ksl-lib.mjs";
import { syncKslToolEnv } from "../config/load-projects.mjs";

export function cmdPlan(flags, positional, cwd, wsOptions = {}) {
  if (positional.length > 1) {
    console.error(`Unexpected argument: ${positional[1]}`);
    return 2;
  }
  if (!["human", "json"].includes(flags.format)) {
    console.error("--format must be human or json.");
    return 2;
  }
  syncKslToolEnv(cwd, wsOptions);
  let spec;
  try {
    spec = resolveSpecPath(positional[0] ?? ".", cwd);
  } catch (e) {
    console.error(e.message);
    return 2;
  }
  try {
    runPlan(spec, {
      kinds: flags.kinds,
      format: flags.format,
    });
  } catch (e) {
    console.error(e.message ?? e);
    return 2;
  }
  return 0;
}
