import { readCliVersion } from "../config/manifest.mjs";

export function globalHelp() {
  const v = readCliVersion();
  return `Yadra CLI v${v} — Ingénierie formelle KSL

Usage:
  yadra <commande> [options]

Commandes:
  version      Affiche la version CLI (yadra/manifest.mf) et l'état du contexte
  help         Aide globale ou yadra <commande> -h
  configure    Profils LLM et credentials (~/.config/yadra/)
  context      KSL_PROJECT_HOME, PROJECT_HOME, YADRA_PROJECT_HOME, modèle
  formalize    Si KSL absent : infos A/B ; si présent : validate + seal
  validate     Validation KSL L0–L3
  seal         Scellement T1 (.yadra/sealed/)
  doctor       Diagnostic environnement

Exécutez "yadra <commande> -h" pour le détail.`;
}

export function commandHelp(name) {
  const map = {
    version: `Usage: yadra version [--format human|json]

Affiche la version lue depuis yadra/manifest.mf, KSL_HOME, grammaire et contexte.`,
    help: `Usage: yadra help [commande]
       yadra -h`,
    configure: `Usage:
  yadra configure list
  yadra configure set --profile <nom> [--provider <id>] [--model <id>] [--base-url <url>] [--timeout <ms>]
  yadra configure credentials --profile <nom> [--token <val>] [--username <u>] [--password <p>]
  yadra configure get <clé> [--profile <nom>]

Stocke configure et credentials sous ~/.config/yadra/.`,
    context: `Usage:
  yadra context set --ksl-project-home <path> [options]
  yadra context show
  yadra context export
  yadra context clear

Options (set):
  --ksl-project-home <path>   Monorepo specs (kind = root)
  --project-home <path>       Code applicatif généré
  --yadra-project-home <path> Distribution Yadra
  --model <id>                Modèle par défaut (runtime SKILLS A/B)
  --profile <name>            Profil configure`,
    formalize: `Usage: yadra formalize <dossier-documents> [options]

Prérequis : yadra context set --ksl-project-home <path>
Entrée obligatoire : <dossier-documents>/feature.yadra.md (output_paths.spec requis).

Si un fichier listé dans output_paths (root, module, spec) manque sous KSL_PROJECT_HOME :
  crée KSL_PROJECT_HOME/.yadra/tmp/<run-id>/, affiche chemins plans/skills, code sortie 1.
Si tous existent :
  yadra validate sur chaque fichier (L0+L2+L3, +L1 si --syntax), puis yadra seal (défaut).

Le binaire n'exécute pas de LLM ni ne génère de .ksl.

Options:
  --seal / --no-seal   Scellement (défaut : --seal)
  --syntax             L1 lors de validate/seal
  --include <paths>    Fichiers .ksl extra pour seal
  --ksl-project-home, --project-home, --yadra-project-home
  --model, --profile   Surcharge env (affichées si branche A/B)`,
    validate: `Usage: yadra validate [PATH] [--syntax] [--layout] [--semantic] [--format human|json]`,
    seal: `Usage: yadra seal [SPEC.spec.ksl] [--syntax] [--include path,...]`,
    doctor: `Usage: yadra doctor

Vérifie Node, manifest, KSL_HOME, contexte.`,
  };
  return map[name] ?? `No help for: ${name}\n\n${globalHelp()}`;
}
