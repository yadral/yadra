# Yadra CLI

Binaire **`yadra`** (Node ≥ 18). Distribution embarquée dans `vendor/` (tarball) ou lien monorepo (`npm install` / `prepare`).

## Install dev — option 2 (tarball)

### Qui publie le `.tgz`

Depuis la racine du monorepo :

```bash
cd yadra/cli
npm run pack:release
# → iyadris-yadra-0.1.0.tgz (nom npm = @iyadris/yadra)
```

Joindre le fichier à une **release GitHub** (ou artefact CI).

Contenu du paquet : CLI + `vendor/iyadris-yadra/` (grammaire, lib KSL, `yadra/manifest.mf`, skills, plans T1).

### Qui installe

Node 18+ :

```bash
npm install -g ./iyadris-yadra-0.1.0.tgz
yadra version
```

`YADRA_PROJECT_HOME` et `KSL_HOME` sont définis au démarrage depuis la distribution installée — **pas** de `--yadra-project-home` en usage normal.

Contexte métier :

```bash
yadra context set --ksl-project-home /chemin/vers/monorepo-ksl
```

## Développement dans le monorepo

```bash
cd yadra/cli
npm install    # prepare → copie vendor/iyadris-yadra
npm test
npm link       # optionnel : yadra sur le PATH
```

Doc utilisateur : [`../documentation/`](../documentation/).
